export default function Home(){ return (
  <div style={{padding:30,fontFamily:'sans-serif'}}>
    <h1>Amplified — Demo</h1>
    <p>Welcome. This is a placeholder frontend. Replace with your real UI and connect to the API.</p>
  </div>
) }
